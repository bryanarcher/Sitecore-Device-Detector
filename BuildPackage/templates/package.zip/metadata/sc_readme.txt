New Sitecore Device Rules & Conditions
--------------------------------------

* Device type - covers Smartphone, Tablet, Desktop, eReader, TV and many more

* Screen size - details of both physical and pixel screen size

* Has touch screen flag

* plus supports the full range of 51Degrees properties and values - THE fastest and most accurate device detection


For Developers
--------------

Use code like...

Request.Browser["IsMobile"]

or 

Request.Browser["IsTablet"]

... from within a web application server side to determine the requesting device type.

Include...

https://[YOUR DOMAIN]/51Degrees.features.js?DeviceType&ScreenInchesDiagonal

... from Javascript to retrieve device type and physcial screen size information. Use Google Analytics custom dimensions to add this data for more granular analysis.


Device Database Options
-----------------------

See this link for compaitable device data options:

https://51degrees.com/compare-data-options?AffiliateId=5